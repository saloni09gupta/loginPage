<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<script type="text/javascript" src="jquery.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("#login-btn").on("click", function(){
				window.location.href="hotelHome.php";
			});
		});
	</script>
<style type="text/css">
	    #backarea{
      		margin: 2px;
      		padding: 2px;
      		box-sizing: border-box;
      		font-family: sans-serif;
     		background-image: url(hotel.jpg);
      		background-size: 5399px 3000px;
      		background-repeat: no-repeat;
      		background-attachment: fixed;
        }
    #div1{
    	 background: rgba(0, 0, 0, 0.3);
    	 height: 2455px;
		left: 0;
		top: 0;
		width: 100%;
    }
    #div2{
    	background: rgba(0, 0, 0, 0.5);
    	position: relative;
    	width: 1700px;
    	height: 1500px;
    	padding: 30px;
    	left: 35%;
    	top: 10%;
    }
    #heading{
    	font-family: sans-serif;
    	font-size: 100px;
    	color: white;
    	text-align: center;
    }
    .text{
    	font-family: sans-serif;
    	font-size: 50px;
    	text-align: center;
    	padding: 10px 20px;
    	width: 90%;
    	height: 7%;
    	margin: 30px;
    }
    .tick{
    	padding: 10px 20px;
    	width: 5%;
    	height: 5%;
    	margin: 30px;
    }
    .t{
    	color: white;
    	font-size: 60px;
    	font-family: cursive;
    }
    #login-btn{
    	text-align: center;
    	padding: 20px 30px;
    	font-size: 45px;
    	font-family: sans-serif;
    	margin: 70px;
    	margin-left: 500px;
    	width: 40%;
    	background: steelblue;
    	border-bottom: solid black;
    	border-right: solid black;
    	cursor: pointer;
    }
    #login-btn:active{
    	background-color: brown;
    	box-shadow: 0 5px #666;
    	transform: translateY(10px);
    }
    #login-btn:hover{
    	background-color: burlywood;
    }
    ::placeholder{
    	color: black;
    }
    .p1{
    	font-size: 50px;
    	color: white;
    	text-align: center;
    	font-family: sans-serif;
    }
</style>
</head>
<body id="backarea">
	<div id="div1">
		<div id="div2">
			<h1 id="heading">Login Here</h1>
			<input type="text" class="text" name="name" placeholder="Username or Email"><br>
			<input type="password" class="text" name="pwd" placeholder="Password"><br>
			<input type="checkbox" class="tick" name="tick"><label class="t">Remember me</label><br>
			<input type="submit" id="login-btn" name="login" value="LOGIN"><br>
			<p class="p1">FORGET PASSWORD</p>
			<p class="p1">New TO THE HOTEL? REGISTER NOW</p>
		</div>
	</div>	
</body>
</html>