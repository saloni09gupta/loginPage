<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Welcome Page</title>
	<script type="text/javascript" src="jquery.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("#btn").on("click", function(){
				window.location.href="login.php";
			});
		});
	</script>
	<style type="text/css">
		#model{
			padding: 10px;
			margin: 2px;
			background-image: url(home.jpg);
			background-repeat: no-repeat;
			background-size: 5399px 2500px;
			background-attachment: fixed ;
		}
		#btn{
			background: red;
			color: white;
			border-radius: 50%;
			top: 20px;
			right: 40px;
			height: 80px;
			width: 80px;
			position: absolute;
			cursor: pointer;
			line-height: 25px;
			text-align: center;
			font-size: 60px;
		}
	</style>
</head>
<body id="model">
	<div id="btn">X</div>
</body>
</html>